running_in_phonegap = true;

try 
	{
	StatusBar.hide();
	} 
catch (e) 
	{
	running_in_phonegap = false;
	};
	
if (!running_in_phonegap) 
	
	{
	// RocketMobileApplication.getEntity("HOST").setValue("http://demoportal.rocketsoftware.com:8181/apa-webcontent-war-1.3/proxy/den-l-dg01");
	}
